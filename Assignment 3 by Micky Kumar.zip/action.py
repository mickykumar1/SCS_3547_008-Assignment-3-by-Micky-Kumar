# -*- coding: utf-8 -*-
"""
Created on Wed Oct  7 09:23:41 2020

@author: Micky
"""

straight = 0
left = 1
right = 2
back = 3
grab = 4
shoot = 5
climb = 6

       