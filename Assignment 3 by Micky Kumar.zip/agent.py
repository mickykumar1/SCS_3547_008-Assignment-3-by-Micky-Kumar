# -*- coding: utf-8 -*-
"""
Created on Tue Oct  6 21:42:54 2020

@author: Micky
"""

def direction(self, forward, TurnLeft, TurnRight): #direction of the agent
    self.forward = forward
    self.TurnLeft = TurnLeft
    self.TurnRight = TurnRight
    
    
