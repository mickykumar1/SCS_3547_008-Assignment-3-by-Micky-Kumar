# -*- coding: utf-8 -*-
"""
Created on Wed Oct  7 11:52:51 2020

@author: Micky
"""

s_points = 1000
win = 1000
loss = 1000.
action = -1
arrow = 10
